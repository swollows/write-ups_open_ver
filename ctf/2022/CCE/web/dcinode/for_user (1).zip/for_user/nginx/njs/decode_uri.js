
function dec(r) {
    return decodeURIComponent(r.uri);
 }

export default { dec }
