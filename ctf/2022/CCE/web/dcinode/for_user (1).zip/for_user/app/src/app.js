#!/usr/bin/node
const express = require("express");
const session = require('express-session'); 
const crypto = require("crypto");

const { User, Chat, Post, Comment } = require("./lib/db");
const main_routes = require('./routes/main');
const api_routes = require('./routes/api');
const hashPasswd = p => { return crypto.createHash('sha256').update(p).digest('hex') }

const app = express();
app.set("view engine", "ejs");
app.set("views", __dirname + "/views"); 
app.use(express.urlencoded());

app.use(
    session({
      saveUninitialized: true,
      resave: false,
      secret: "[REDACTED]",
    })
);

app.use((req,res,next)=>{
    req.url = (new URL("http://"+req.hostname+req.url)).pathname
    next();
})

app.use('/', main_routes);
app.use('/api', api_routes);
app.use('/static', express.static('static'));

app.listen(8000, () => {
  setTimeout(async ()=>{
    await User.create({
    user: "admin",
    password: hashPasswd("[REDACTED]"),
    ip: "127.0.0.1"
  });
},10000)
  console.log("listen on 8000");
});
