const express = require("express");
const { User, Chat, Post, Comment } = require("../lib/db");
const router = express.Router();
const crypto = require("crypto");
const { visit } = require('../lib/bot');

const hashPasswd = p => { return crypto.createHash('sha256').update(p).digest('hex') }

router.post('/register', async (req, res) => {
    const { username, password } = req.body;
    if(!username || !password) {
        return res.redirect("/register?error=Missing Parameter");
    }

    if(await User.findByPk(username)) {
        return res.redirect("/register?error=Already exists");
    }
    try {
        await User.create({
            user: username,
            password: hashPasswd(password),
            ip: req.ip
        });
    } catch(e) {
        return res.redirect("/register");
    }

    return res.redirect('/login');
});

router.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;

        if(!username || !password) {
            return res.redirect("/login?error=Missing Parameter");
        }

        let user = await User.findByPk(username);
        if(!user) {
            return res.redirect("/login?error=user not found");
        }

        if(hashPasswd(password) !== user.password) {
            return res.redirect("/login?error=Incorrect password");
        }

        req.session.user = user.user;
        return res.cookie('user', req.session.user).redirect('/');
    } catch {
        return res.redirect("/login?error=error");
    }
});

router.get('/logout', async (req, res) => {
    req.session.destroy();
    return res.clearCookie('user').redirect('/');
});

router.get('/profile/:userid', async (req, res) =>{ // for admin
    const userid = req.params.userid;
    if(req.session.user === "admin") {
        let user;
        try {
            user = await User.findOne({
                where: { user: userid }
            })
        } catch {
            return res.setHeader("Content-Type","application/json").render("json", { status:"500", msg: "error" });
        }

        if(!user) {
            return res.setHeader("Content-Type","application/json").render('json',{ status:"404", msg: "Not Found" });
        }
        return res.setHeader("Content-Type","application/json").render("profile_json", { user });
    } else {
        return res.setHeader("Content-Type","application/json").render("json", { status:"403", msg: "you cant read other user's profile." });
    }
});

router.post("/profile", async (req, res) => {
    if(!req.session.user) {
        return res.redirect('/login');
    }
    const { newpassword, checkpassword, userBio } = req.body;
    let user;
    try {
        user = await User.findOne({
            where: { user: req.session.user }
        })
    } catch {
        return res.redirect("/profile?error=error");
    }

    if(hashPasswd(checkpassword) !== user.password) {
        return res.redirect("/profile?error=Incorrect password");
    }
    if (newpassword) {
        User.update({
            profileBio: userBio,
            password: hashPasswd(newpassword)
        },{
            where: {
                user: req.session.user
            }
        });
    } else {
        User.update({
            profileBio: userBio
        },{
            where: {
                user: req.session.user
            }
        });
    }
    return res.redirect('/profile');
});

router.get('/chat/:id', async (req, res) => {
    if(!req.session.user) {
        return res.setHeader("Content-Type","application/json").render('json',{ status:"401", msg: "unauthorized" });
    }
    const id = req.params.id;
    const chatroom = await Chat.findOne({
        where: { id: id }
    })
    if(!chatroom) {
        return res.setHeader("Content-Type","application/json").render('json',{ status:"404", msg: "Not Found" });
    }
    const participant = JSON.parse(chatroom.participant);
    if(!participant.includes(req.session.user)){
        return res.setHeader("Content-Type","application/json").render('json',{ status:"404", msg: "Not Found" });
    }

    return res.setHeader("Content-Type","application/json").render("chat_data", { data: chatroom.get().message });
});

router.post('/chat/create', async (req, res) => {
    if(!req.session.user) {
        return res.setHeader("Content-Type","application/json").render('json',{ status:"401", msg: "unauthorized" });
    }
    const { username } = req.body;

    if(username === req.session.user) {
        return res.setHeader("Content-Type","application/json").render('json',{ status:"400", msg: "you cant make a channel with yourself" }); 
    }

    const user = await User.findByPk(username);
    if(!user) {
        return res.setHeader("Content-Type","application/json").render('json',{ status:"404", msg: "User does not exist" }); 
    }

    let chat;
    try {
        chat = await Chat.findAll();
        for(let c of chat) {
            const tmp = JSON.parse(c.participant);
            if(tmp.includes(req.session.user) && tmp.includes(username)) {
                return res.setHeader("Content-Type","application/json").render('json',{ status:"500", msg: "already exist" }); 
            }
        }
        await Chat.create({
            participant: JSON.stringify([req.session.user,username]),
            message: JSON.stringify([])
        });
    } catch {
        return res.setHeader("Content-Type","application/json").render('json',{ status:"500", msg: "error" }); 
    }
    return res.setHeader("Content-Type","application/json").render('json',{ status:"200", msg: "Success" }); 
});


router.post('/chat/:id/send', async (req, res) => {
    if(!req.session.user) {
        return res.setHeader("Content-Type","application/json").render('json',{ status:"401", msg: "unauthorized" });
    }
    const id = req.params.id;
    let { message } = req.body;
    const chatroom = await Chat.findOne({
        where: { id: id }
    })

    if(!chatroom) {
        return res.setHeader("Content-Type","application/json").render('json',{ status:"404", msg: "Not Found" });
    }

    if(!message) {
        return res.setHeader("Content-Type","application/json").render('json',{ status:"400", msg: "Message required" });
    }

    const participant = JSON.parse(chatroom.participant);
    if(!participant.includes(req.session.user)){
        return res.setHeader("Content-Type","application/json").render('json',{ status:"401", msg: "unauthorized" });
    }
    try {
        const data = JSON.parse(chatroom.message);
        message = message.replaceAll(process.env.FLAG,"REDACTED");

        data.push({
            user: req.session.user,
            message: message
        });

        Chat.update(
            {
                message: JSON.stringify(data)
            },
            {
                where: {
                    id: id
                }
            }
        )
        if(participant.includes("admin") && req.session.user !== "admin") {
            visit(id);
        }
    } catch {
        return res.setHeader("Content-Type","application/json").render('json',{ status:"500", msg: "Error" });
    }
    return res.setHeader("Content-Type","application/json").render('json',{ status:"200", msg: "Success" }); 
});

router.post('/post/write', async (req, res) => {
    if(!req.session.user) {
        return res.render('json',{ msg: "unauthorized" });
    }
    const { title, content } = req.body;
    let post;
    try {
        post = await Post.create({
            title: title,
            content: content,
            ip: req.header('CF-Connecting-IP')
        });
        const user = await User.findByPk(req.session.user);
        user.addPost(post);
        post.setUser(user);
    } catch {
        return res.render("500");
    }
    return res.redirect('/posts');
});

router.post('/post/delete/:id', async (req, res) => {
    if(!req.session.user) {
        return res.setHeader("Content-Type","application/json").render('json',{ status:"401", msg: "unauthorized" });
    }
    const id = req.params.id;
    if(!id) {
        return res.setHeader("Content-Type","application/json").render("json",{ status:"400", msg: "Missing Parameter" });
    }
    let post;
    try {
        post = await Post.findByPk(id);
        if((await post.getUser()).user !== req.session.user){
            return res.setHeader("Content-Type","application/json").render("json",{ status:"403", msg: "you cant delete other user's post" });
        }
        await post.destroy();
        for(let c of await post.getComments()) {
            await c.destroy();
        }
    } catch {
        return res.setHeader("Content-Type","application/json").render("json",{ status:"500", msg: "error" });
    }
    return res.setHeader("Content-Type","application/json").render("json", { status:"200", msg: "Success" });
});

router.post('/post/comment/:id', async (req, res) => {
    if(!req.session.user) {
        return res.setHeader("Content-Type","application/json").render('json',{ status:"401", msg: "unauthorized" });
    }
    const id = req.params.id;
    const { content } = req.body;
    if(!id || !content) {
        return res.setHeader("Content-Type","application/json").render("json",{ status:"400", msg: "Missing Parameter" });
    }
    let post = await Post.findByPk(id);
    if(!post) {
        return res.setHeader("Content-Type","application/json").render("json",{ status:"404", msg: "Not Found" });
    }
    let comment;
    try {
        comment = await Comment.create({
            content: content,
            ip: req.header('CF-Connecting-IP')
        });
        const user = await User.findByPk(req.session.user);
        comment.setUser(user);
        comment.setPost(post);
        post.addComment(comment);
    }
    catch { 
        return res.setHeader("Content-Type","application/json").render("json",{ status:"500", msg: "error" });
    }
    return res.setHeader("Content-Type","application/json").render("json", { status:"200", msg: "Success" });
});

module.exports = router;