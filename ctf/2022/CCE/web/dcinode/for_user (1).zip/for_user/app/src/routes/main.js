const express = require("express");
const moment = require("moment");
const { Post, User, Chat } = require("../lib/db");
const router = express.Router();

router.get('/', (req, res) => {
    return res.render('index');
});

router.get('/login', (req, res) => {
    if(req.session.user) {
        return res.redirect('/');
    } else {
        return res.render('login',{e:false});
    }
});

router.get("/posts", async (req, res) => {
    const posts = await Post.findAll();
    if(!posts) {
        res.render("posts", { posts: [] });
    }
    const post = [];
    for(let c of posts) {
        post.push({ id: c.id, title: c.title, user: await c.getUser(), createTime: moment(c.createdAt).format('YYYY/MM/DD HH:mm:SS'), ip: c.ip });     
    }
    res.render("posts", { list: post });
});

router.get('/register', (req, res) => {
    if(req.session.user) {
        return res.redirect('/');
    } else {
        return res.render('register',{ e:false });
    }
});

router.get("/profile", async (req, res) => {
    if(!req.session.user) {
        return res.redirect('/login');
    } else {
        const user = await User.findOne({
            where: { user: req.session.user }
        })
        if(!user) {
            return res.redirect("/?error=user not found");
        }
        return res.render("profile", { user: user.get() });
    }
});

router.get("/write", (req, res) => {
    if(!req.session.user) {
        return res.redirect('/login');
    } else {
        return res.render("write");
    }
});

router.get("/post/:id", async (req, res) => {
    let id = req.params.id;
    if(!id) {
        return res.redirect("/posts?error=where is id?");
    }
    const post = await Post.findByPk(id);
    if(!post) {
        return res.redirect("/posts?error=not found");
    }
    const author = await post.getUser();
    const comments = [];
    for(let c of await post.getComments()) {
        comments.push({ content: c.content, ip: c.ip, user: await c.getUser() });     
    }
    res.render("post", { post, author: author.user, createTime: moment(post.createdAt).format('YYYY/MM/DD HH:mm:SS'), comments });
});

router.get("/chat", async (req, res) => {
    if(!req.session.user) {
        return res.redirect('/login');
    } else {
        const list = await Chat.findAll();
        if(!list) {
            return res.render("chat", { list: [] });
        }
        return res.render("chat", { list: list.filter(x => JSON.parse(x.participant).includes(req.session.user)) });
    }
});

router.get("/chat/:id", async (req, res) => {
    let id = req.params.id;
    if(!id) {
        return res.redirect("/chat?error=where is id?");
    }

    if(!req.session.user) {
        return res.redirect('/login');
    }

    const chat = await Chat.findOne({
        where: { id: id }
    });

    if(!chat) {
        return res.redirect("/chat?error=not found");
    }

    const participant = JSON.parse(chat.participant);
    if(!participant.includes(req.session.user)){
        return res.redirect('/chat?error=unauthorized');
    }

    return res.render("chatroom", { chat });
});

module.exports = router;