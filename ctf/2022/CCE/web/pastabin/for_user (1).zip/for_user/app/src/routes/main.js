const express = require("express");
const router = express.Router();
const { encode } = require("html-entities");
const { uuid } = require("uuidv4");
const crypto = require("crypto");

const hashPasswd = p => { return crypto.createHash('sha256').update(p).digest('hex') }

const users = new Set();
const notes = new Map([
    []
]);

const note_data = new Map([
]);

users.add({
    "username" : "admin",
    "pw" : hashPasswd("[REDACTED]"),
    "uuid" : uuid()
});

let admin_tmp = uuid();
notes.set("admin", [{
    key: admin_tmp,
    title: "This is Flag",
    content: "cce2022{this_is_not_real_flag}",
}]);

note_data.set(admin_tmp,"admin");

router.get('/', (req, res) => {
    if(!req.session.user) {
        return res.redirect('/login');
    }
    const data = notes.get(req.session.user.username);
    if (data) {
        const tmp = [];
        data.forEach((obj) => {
            let _ = {};
            for (let key in obj){
                if (key == 'content'){ 
                    continue
                }
                _[key] = obj[key];
            }
            tmp.push(_)
        });
        return res.render('index', { data: JSON.stringify(tmp) });
    } else {
        return res.render('index', { data: JSON.stringify([]) });
    }
});

router.get('/login', (req, res) => {
    if(req.session.user) {
        return res.redirect('/');
    } else {
        return res.render('login',{e:false});
    }
});

router.post('/login', (req, res) => {
    if(req.session.user) {
        return res.redirect('/');
    } else {
        const { username, password } = req.body;
        pw_hash = hashPasswd(password);

        let u = null
	    for(let e of users.entries())
		    if(e[0].username === username.toString())
			    u = e[0];
        
        if(!u) {
		    return res.render("login",{ e:"Not found user"});
        }
        
        if(u.pw != pw_hash) {
            return res.render("login",{ e:"password incorrect"});
        }

        req.session.user = {
            "username": username,
            "uuid": u.uuid,
        }
        return res.redirect('/');
    }
});

router.get('/register', (req, res) => {
    if(req.session.user) {
        return res.redirect('/');
    } else {
        return res.render('register',{e:false});
    }
});

router.post('/register', (req, res) => {
    if(req.session.user) {
        return res.redirect('/');
    } else {
        const { username, password } = req.body;
        if ( username.length < 5 || username.length > 20 || typeof username !== 'string' || password.length < 5 || typeof password !== 'string') {
            return res.render('register', { e: "invalid data, please check rule about username and password" });
        }
        for(let e of users.entries())
		    if(e[0].username === username.toString())
                return res.render("register",{ e:"Username exist!" })
        
        pw_hash = hashPasswd(password);

        user_uuid = uuid();
        users.add({
            "username" : username,
            "pw" : pw_hash,
            "uuid" : user_uuid
        });
        
        return res.redirect('/login');
    }
});

router.get('/addnote', (req, res) => {
    if(!req.session.user) {
        return res.redirect('/login');
    } else {
       return res.render("addnote");
    }
});

router.post('/addnote', (req, res) => {
    if(!req.session.user) {
        return res.redirect('/login');
    } else {
        const { title, content } = req.body;
        const user_notes = notes.get(req.session.user.username) || [];
        const key = uuid();
        user_notes.push({
            key,
            title: encode(title),
            content: encode(content),
        });

        note_data.set(key, req.session.user.username);
        notes.set(req.session.user.username, user_notes);

        return res.redirect('/');
    }
})

router.get('/view/:id', (req, res) => {
    if(req.hostname != "sandbox.example.com") {
        if(!req.session.user) {
            return res.redirect('/login');
        } else {
            if (req.session.user.username === "admin") {
                const data = note_data.get(req.params.id);
                const user_notes = data && notes.get(data);
                const found = user_notes && user_notes.find(note => note.key === req.params.id);
                if (found) {
                    return res.json(found);
                } else {
                    return res.json({err: "Not Found!"});
                }
            } else {
                const user_notes = notes.get(req.session.user.username);
                const found = user_notes && user_notes.find(note => note.key === req.params.id);
                if (found) {
                    return res.json(found);
                } else {
                    return res.json({err: "Not Found!"});
                }
            }
        }
    } else {
        return res.setHeader("Content-Security-Policy","frame-ancestors http://*.example.com").render("sandbox")
    }
})

module.exports = router;
