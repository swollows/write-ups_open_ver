#!/usr/bin/node
const express = require("express");
const session = require('express-session'); 

const routes = require('./routes/main');

const app = express();
app.set("view engine", "ejs");
app.set("views", __dirname + "/views"); 
app.use(express.urlencoded());

app.use(
    session({
      saveUninitialized: true,
      resave: false,
      secret: "[REDACTED]",
    })
);
app.use('/', routes);

app.listen(80, () => {
    console.log("listen on 8000");
});
