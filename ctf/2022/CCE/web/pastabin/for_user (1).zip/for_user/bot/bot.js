const puppeteer = require('puppeteer')
const ADMIN_PASSWORD = "[REDACTED]"

async function visit(path) {
    const browser = await puppeteer.launch({
        headless: true,
        args: [
            "--no-sandbox",
            "--disable-setuid-sandbox",
            "--js-flags=--noexpose_wasm,--jitless",
        ],
        executablePath: '/usr/bin/google-chrome'
    })


    try {
        let page = await browser.newPage()

        await page.goto(`http://pastabin.ssrf.kr:${process.env.PORT}/login`)

        await page.waitForSelector('#username')
        await page.focus('#username')
        await page.keyboard.type("admin", { delay: 10 })

        await page.waitForSelector('#password')
        await page.focus('#password')
        await page.keyboard.type(ADMIN_PASSWORD, { delay: 10 })

        await new Promise(resolve => setTimeout(resolve, 300))
        await page.click('#submit')
        await new Promise(resolve => setTimeout(resolve, 300))

        await page.goto(`http://pastabin.ssrf.kr:${process.env.PORT}${path}`, { timeout: 5000 })
        await new Promise(resolve => setTimeout(resolve, 10000))
        await page.close()
        await browser.close()
    } catch (e) {
        console.log(e)
        await browser.close()
    }

}

module.exports = { visit }
