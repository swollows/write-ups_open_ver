const express = require('express')
const bot = require('./bot')

const checkoutTimes = new Map()
const now = () => { return Math.floor(+new Date()/1000) }
const app = express()
app.use(express.json());


app.post('/visit', async function (req, res) {

    const url = req.body.url;
    if (typeof url === 'string' && /\/#view\/[0-9a-f]{8}-[0-9a-f]{4}-[4][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(url)) {
        try {
            if(checkoutTimes.has(req.ip) && checkoutTimes.get(req.ip)+30 > now()) {
		        return res.json({ error: 'too fast'})
	        }
	        checkoutTimes.set(req.ip,now())
            bot.visit(url);
            return res.json({ msg: 'visited' });
        } catch (e) {
            return res.status(500).json({ error: 'failed' });
        }
    }
    res.status(400).json({ error: 'bad url' });
})


app.listen(8888, '0.0.0.0');
