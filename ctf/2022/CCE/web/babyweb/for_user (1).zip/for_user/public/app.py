import urllib
import urllib.parse
import requests
import ipaddress
from flask import Flask
from flask import request
import socket

app = Flask(__name__)

data = """
<html>
<head>
<title>BabyWeb</title>
</head>
<body>
<form action="/" method="POST">
<input type="text" name="url">
<input type="submit">
</form>
</body>
</html>
"""

def valid_ip(ip):
    try:
        ip = socket.gethostbyname(ip)
        is_internal = ipaddress.ip_address(ip).is_global
        if(is_internal):
            return False
        else:
            return True
    except:
        pass

@app.route('/', methods=['GET','POST'])
def index():
    if request.method == "POST":
        try:
            url = request.form['url']
            result = urllib.parse.urlparse(url)
            if result.hostname == 'flag.service':
                return "Not allow"
            else:
                if(valid_ip(result.hostname)):
                    return "huh??"
                else:
                    return requests.get("http://"+result.hostname+result.path, allow_redirects=False).text
        except:
            return "Something wrong..."
    elif request.method == "GET":
        return data

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80)