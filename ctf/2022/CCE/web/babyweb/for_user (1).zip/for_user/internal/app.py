from flask import Flask
from flask import request
from secret import FLAG

app = Flask(__name__)


@app.route('/flag', methods=['GET'])
def index():
    if request.host == "flag.service":
        return FLAG
    else:
        return "Nice try :)"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80)