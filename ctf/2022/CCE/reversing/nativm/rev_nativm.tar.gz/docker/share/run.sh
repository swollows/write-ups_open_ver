#!/bin/bash

cd /home/ctf
python3 run.py
